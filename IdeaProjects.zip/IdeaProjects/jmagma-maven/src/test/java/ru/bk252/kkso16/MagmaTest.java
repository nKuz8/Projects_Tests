package ru.bk252.kkso16;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.provider.MethodSource;
import org.junit.jupiter.params.provider.ValueSource;

public class MagmaTest
{
    @Test
    public void testEnc()
    {
        long openBlock = 0xfedcba9876543210L;
        int[] key = new int[] {0xffeeddcc, 0xbbaa9988, 0x77665544, 0x33221100, 0xf0f1f2f3, 0xf4f5f6f7, 0xf8f9fafb, 0xfcfdfeff};

        Magma EncCheck = new Magma(key);

        assertEquals(EncCheck.encryptBlock(openBlock), 0x4ee901e5c2d8ca3dL);
    }

    @Test
    public void testDec() {
        long cipherBlock = 0x4ee901e5c2d8ca3dL;
        int[] key = new int[] {0xffeeddcc, 0xbbaa9988, 0x77665544, 0x33221100, 0xf0f1f2f3, 0xf4f5f6f7, 0xf8f9fafb, 0xfcfdfeff};

        Magma DecCheck = new Magma(key);

        assertEquals(DecCheck.decryptBlock(cipherBlock), 0xfedcba9876543210L);
    }


}
