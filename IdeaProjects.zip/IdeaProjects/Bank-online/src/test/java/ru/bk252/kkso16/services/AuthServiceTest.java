package ru.bk252.kkso16.services;

import static org.junit.jupiter.api.Assertions.*;
import static org.assertj.core.api.Assertions.*;
import static org.mockito.Mockito.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.Mock;
import ru.bk252.kkso16.model.User;
import ru.bk252.kkso16.dao.UserDao;
import ru.bk252.kkso16.utils.PasswordHasher;

@ExtendWith(MockitoExtension.class)
public class AuthServiceTest {
    @Mock
    private UserDao userDao;
    @Mock
    private PasswordHasher passwordHasher;

    private AuthService authService;

    @BeforeEach
    public void setUp() {
        authService = new AuthService(userDao, passwordHasher);
    }

    /**
     * Позитивный тест регистрации в системе пользователя petrov@email.ru с паролем pa$$w0rd1111
     */
    @Test
    public void RegisterNewUserShouldSuccess() {
        // сконфигурируем mock-объектам поведение, требуемое для выполнения позитивного теста.
        // Т.е. метод create объекта UserDao должен быть вызыван с параметром email, равным petrov@email.ru,
        // а параметру password после вызова должно быть присвоено значение хэш-функции от пароля pa$$w0rd1111.
        // Предположим, используется произвольная хэш-функция, которая для строки pa$$w0rd1111 дает значение
        // "12345678".

        when(passwordHasher.computeHash("pa$$w0rd1111"))
                .thenReturn("12345678");

        when(userDao.create("petrov@email.ru", "12345678"))
                .thenReturn(new User("petrov@email.ru", "petrov", "12345678", "USER"));

        User newUser = authService.Register("petrov@email.ru", "pa$$w0rd1111");
        assertThat(newUser.getEmail()).isEqualTo("petrov@email.ru");
    }

    @Test
    public void RegisterWithEmptyEmailShouldThrowException() {
        Exception e = assertThrows(
                IllegalArgumentException.class,
                () -> {
                    User newUser = authService.Register("", "pa$$w0rd1111");
                }
        );

        assertThat(e.getMessage()).isEqualTo("email is empty");
    }

    @Test
    public void RegisterWithPasswordTooShortShouldThrowException() {
        Exception e = assertThrows(
                IllegalArgumentException.class,
                () -> {
                    User newUser = authService.Register("somemail@mail.ru", "password");
                }
        );

        assertThat(e.getMessage()).isEqualTo("password to short");
    }

    @Test
    public void RegisterPresenceUserShouldReturnNull() {
        when(passwordHasher.computeHash("pa$$w0rd1111"))
                .thenReturn("12345678");

        when(userDao.create("admin@gmail.com", "12345678")).thenReturn(null);

        User newUser = authService.Register("admin@gmail.com", "pa$$w0rd1111");
        assertThat(newUser).isEqualTo(null);
    }

    @Test
    public void LoginPresenceUserWithCorrectCredentialsShouldSuccess() {
        when(userDao.findByEmail("petrov@mail.ru")).thenReturn(
                new User("petrov@mail.ru", "petrov", "12345678", "USER")
        );

        when(passwordHasher.computeHash("pa$$w0rd1111")).thenReturn("12345678");

        User newUser = authService.Login("petrov@mail.ru", "pa$$w0rd1111");
        assertThat(newUser.getEmail()).isEqualTo("petrov@mail.ru");
    }

    @Test
    public void LoginUnpresenceUserShouldReturnNull() {
        when(userDao.findByEmail("nikita@gmail.com")).thenReturn(null);

        User newUser = authService.Login("nikita@gmail.com", "pa$$w0rd1111");
        assertThat(newUser).isEqualTo(null);
    }

    @Test
    public void LoginWithWrongPasswordShouldReturnNull() {
        when(userDao.findByEmail("petrov@mail.ru")).thenReturn(
                new User("petrov@mail.ru", "petrov", "12345678", "USER")
        );

        when(passwordHasher.computeHash("pa$$w0rd0000")).thenReturn("11111111");

        User newUser = authService.Login("petrov@mail.ru", "pa$$w0rd0000");
        assertThat(newUser).isEqualTo(null);
    }
}
