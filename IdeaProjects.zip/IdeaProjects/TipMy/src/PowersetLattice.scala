class PowersetLattice[A](ch: A => Boolean) extends Lattice {
  // note: 'ch' isn't used in the class, but having it as a class parameter avoids a lot of type annotations

  type Element = Set[A]

  override def bottom: Element = Set(): Element

  override def lub(x: Element, y: Element) = x | y
}
