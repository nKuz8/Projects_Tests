package ru.bk252.kkso16;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

class PasswordStrengthValidator1Test {
    @ParameterizedTest
    @CsvSource({"Pswd, Too Short", "GlpoYtre, Weak", "17364568, Weak", "Hbv#Fd*b, Medium", "756*6#14, Medium", "Hb5m*bV#, Strong"})
    void testStrengthValidator1(String pass, String str) {
        assertEquals(PasswordStrengthValidator1.checkPassword(pass), str);
    }
}