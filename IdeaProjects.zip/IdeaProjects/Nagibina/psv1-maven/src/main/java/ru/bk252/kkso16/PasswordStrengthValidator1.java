package ru.bk252.kkso16;

public class PasswordStrengthValidator1 {

    public static String checkPassword(String inputPassword) {
        int uppercase = 0;
        int lowercase = 0;
        int specialcharacters = 0;
        int digits = 0;
        char[] Password = inputPassword.toCharArray();
        String result = "";
        for (int index = 0; index < inputPassword.length(); index++) {
            if (Character.isUpperCase(Password[index])) {
                uppercase = 1;
            }
            if (Character.isLowerCase(Password[index])) {
                lowercase = 1;
            }
            if (Character.isDigit(Password[index])) {
                digits = 1;
            }
        }
        if (inputPassword.contains("~") || inputPassword.contains("!") || inputPassword.contains("@")
                || inputPassword.contains("#") || inputPassword.contains("$") || inputPassword.contains("%")
                || inputPassword.contains("^") || inputPassword.contains("&") || inputPassword.contains("*")) {
            specialcharacters = 1;
        }
        if (inputPassword.length() < 8)

            result = "Too Short";

        if (inputPassword.length() >= 8 && (((uppercase == 1) && (lowercase == 1)) || (digits == 1) || (specialcharacters == 1)))

            result = "Weak";

        if ((inputPassword.length() >= 8 && (((uppercase == 1) && (lowercase == 1)) || (digits == 1) && (specialcharacters == 1)))
                &&
                (inputPassword.length() >= 8 && (((uppercase == 1) && (lowercase == 1)) && (digits == 1) || (specialcharacters == 1))))

            result = "Medium";

        if (inputPassword.length() >= 8 && (uppercase == 1) && (lowercase == 1) && (digits == 1) && (specialcharacters == 1))

            result = "Strong";

        return result;
    }
}
