package ru.bk252.kkso16;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;

public class MagmaTest
{
    @Test
    public void testEncryption()
    {
        long openText = 0xfedcba9876543210L;
        int[] key = new int[] {0xffeeddcc, 0xbbaa9988, 0x77665544, 0x33221100, 0xf0f1f2f3, 0xf4f5f6f7, 0xf8f9fafb, 0xfcfdfeff};

        Magma Enc = new Magma(key);

        assertEquals(Enc.encryptBlock(openText), 0x4ee901e5c2d8ca3dL);
    }

    @Test
    public void testDecryption() {
        long cipherText = 0x4ee901e5c2d8ca3dL;
        int[] key = new int[] {0xffeeddcc, 0xbbaa9988, 0x77665544, 0x33221100, 0xf0f1f2f3, 0xf4f5f6f7, 0xf8f9fafb, 0xfcfdfeff};

        Magma Dec = new Magma(key);

        assertEquals(Dec.decryptBlock(cipherText), 0xfedcba9876543210L);
    }


}
