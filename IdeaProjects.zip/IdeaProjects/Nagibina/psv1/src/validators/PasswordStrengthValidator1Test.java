package validators;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;

class PasswordStrengthValidator1Test {
    @Test
    void ifLengthLess8ThenStrengthIsTooShort() {
        String actualStrength = PasswordStrengthValidator1.checkPassword("Pswd");
        String expectedStrength = "Too Short";
        assertEquals(expectedStrength, actualStrength);
    }

    @Test
    void ifLengthGreaterThan8ContainsUpperLowerIsWeak() {
        String actualStrength = PasswordStrengthValidator1.checkPassword("GbvncBgf");
        String expectedStrength = "Weak";
        assertEquals(expectedStrength, actualStrength);
    }

    @Test
    void ifLengthGreaterThan8ContainsDigitIsWeak() {
        String actualStrength = PasswordStrengthValidator1.checkPassword("11115438");
        String expectedStrength = "Weak";
        assertEquals(expectedStrength, actualStrength);
    }

    @Test
    void ifLengthGreaterThan8ContainsUpperLowerSpecialIsMedium() {
        String actualStrength = PasswordStrengthValidator1.checkPassword("Gbf#j*Bd");
        String expectedStrength = "Medium";
        assertEquals(expectedStrength, actualStrength);
    }

    @Test
    void ifLengthGreaterThan8ContainsUpperLowerDigitIsMedium() {
        String actualStrength = PasswordStrengthValidator1.checkPassword("F4b7hCn6");
        String expectedStrength = "Medium";
        assertEquals(expectedStrength, actualStrength);
    }

    @Test
    void ifLengthGreaterThan8ContainsSpecialDigitIsMedium() {
        String actualStrength = PasswordStrengthValidator1.checkPassword("76#7*58~");
        String expectedStrength = "Medium";
        assertEquals(expectedStrength, actualStrength);
    }

    @Test
    void ifLengthGreaterThan8ContainsUpperLowerSpecialDigitIsStrong() {
        String actualStrength = PasswordStrengthValidator1.checkPassword("gB6v*S1#");
        String expectedStrength = "Strong";
        assertEquals(expectedStrength, actualStrength);
    }
}
