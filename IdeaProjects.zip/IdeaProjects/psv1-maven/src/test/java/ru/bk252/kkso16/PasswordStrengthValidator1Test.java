package ru.bk252.kkso16;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

class PasswordStrengthValidator1Test {
    @ParameterizedTest
	@CsvSource({"Pswd, Too Short", "PassWord, Weak", "12345678, Weak", "Pa$$word, Medium", "Passw0rd, Medium", "Pa$$w0rd, Strong"})
    void testStrengthValidator1(String pass, String str) {
		assertEquals(PasswordStrengthValidator1.checkPassword(pass), str);
	}
}
