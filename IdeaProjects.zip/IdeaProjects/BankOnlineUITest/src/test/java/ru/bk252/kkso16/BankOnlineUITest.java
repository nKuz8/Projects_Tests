package ru.bk252.kkso16;

import static org.assertj.core.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.List;

public class BankOnlineUITest
{
    WebDriver webDriver;
    WebDriverWait wait;

    ExpectedCondition<Boolean> pageLoadCondition = driver -> {
        assert driver != null;
        return ((JavascriptExecutor)driver)
                .executeScript("return document.readyState")
                .equals("complete");
    };

    public void registerTestUser(String userName, String password) {
        webDriver.get("https://bank-online.studware.ru/");
        wait.until(pageLoadCondition);

        WebElement loginButton = webDriver.findElement(By.cssSelector(".button"));
        loginButton.click();

        wait.until(pageLoadCondition);

        WebElement registerAnchor = webDriver.findElement(By.linkText("Создать учетную запись"));
        registerAnchor.click();

        wait.until(pageLoadCondition);

        WebElement usernameInput = webDriver.findElement(By.name("username"));
        usernameInput.sendKeys(userName);
        WebElement passwordInput = webDriver.findElement(By.name("password"));
        passwordInput.sendKeys(password);

        WebElement button = webDriver.findElement(By.cssSelector("form button"));
        button.click();
        wait.until(pageLoadCondition);

        WebElement logoutBtn = webDriver.findElement(By.cssSelector("[href=\"/logout/\"]"));
        logoutBtn.click();
        wait.until(pageLoadCondition);
    }

    public void loginTestUser(String userName, String password) {
        webDriver.get("https://bank-online.studware.ru/");
        wait.until(pageLoadCondition);

        WebElement loginButton = webDriver.findElement(By.cssSelector(".button"));
        loginButton.click();
        wait.until(pageLoadCondition);

        WebElement usernameInput = webDriver.findElement(By.name("username"));
        usernameInput.sendKeys(userName);
        WebElement passwordInput = webDriver.findElement(By.name("password"));
        passwordInput.sendKeys(password);

        WebElement button = webDriver.findElement(By.cssSelector("form button"));
        button.click();
        wait.until(pageLoadCondition);
    }

    public void deleteTestUser() {
        WebElement homeBtn = webDriver.findElement(By.cssSelector("a.logo"));
        homeBtn.click();
        wait.until(pageLoadCondition);

        WebElement accountBtn = webDriver.findElement(By.cssSelector("[href=\"/me/\"]"));
        accountBtn.click();
        wait.until(pageLoadCondition);

        WebElement deleteBtn = webDriver.findElement(By.cssSelector("form button"));
        deleteBtn.click();
        Alert deleteAlert = wait.until(ExpectedConditions.alertIsPresent());
        deleteAlert.accept();
    }

    @BeforeEach
    public void setUp()
    {
        webDriver = new FirefoxDriver();
        wait = new WebDriverWait(webDriver, 10);
    }

    @AfterEach
    public void tearDown()
    {
        webDriver.close();
    }

    @Test
    @Order(1)
    public void REGISTER_1_AbsentUsernameShouldShowErrorMessage()
    {
        // Перейдём на главную страницу приложения
        webDriver.get("https://bank-online.studware.ru/");

        // С использованием имени стиля найдём элемент кнопки входа
        WebElement loginButton = webDriver.findElement(By.cssSelector(".button"));
        // Выполним нажатие на кнопку
        loginButton.click();

        // Ожидание загрузки страницы входа
        wait.until(pageLoadCondition);
        // Проверка url адреса страницы входа
        assertThat(webDriver.getCurrentUrl()).contains("https://bank-online.studware.ru/login/");
        // Проверка заголовка стриницы входа
        assertThat(webDriver.getTitle()).isEqualTo("Вход");

        // Поиск элемента ссылки для перехода на страницу регистрации
        WebElement registerAnchor = webDriver.findElement(By.linkText("Создать учетную запись"));
        // Нажатие на ссылку
        registerAnchor.click();

        // Ожидание загрузки страницы регистрации
        wait.until(pageLoadCondition);
        // Проверка url адреса стриницы регситрации
        assertThat(webDriver.getCurrentUrl()).isEqualTo("https://bank-online.studware.ru/register/");
        // Проверка заголовка страницы регстрации
        assertThat(webDriver.getTitle()).isEqualTo("Регистрация");

        // Поиск поля ввода пароля
        // Поле ввода имени пользователя не заполняется,
        // т.к. необходимо проверить требования, что при отсутствии этого поля
        // регистрация не выполняется и показывается сообщение об ошибке
        WebElement passwordInput = webDriver.findElement(By.name("password"));
        passwordInput.sendKeys("Pas5w0rd");

        // Поиск кнопку "Зарегистрировать"
        WebElement button = webDriver.findElement(By.cssSelector("form button"));
        // Нажатие найденной на предыдущем шаге кнопки
        button.click();

        // Ожидание загрузки страницы
        wait.until(pageLoadCondition);
        // Проверка, что остались на той же странице, т.к. регистрация не может
        // быть выполнена, т.к. не было указано имя пользователя
        assertThat(webDriver.getCurrentUrl()).isEqualTo("https://bank-online.studware.ru/register/");

        // Получение всех сообщений об ошибках на форме
        List<WebElement> errorElements = webDriver.findElements(By.className("error"));
        // Проверка, что сообщение об ошибке только одно,
        // т.к. пароль был указан и он соотетствует требованиям безопасности
        assertThat(errorElements.size()).isEqualTo(1);
        assertThat(errorElements.get(0).getText()).isEqualTo("Не указано имя пользователя");
        // Проверка форматирования сообщения красным цветом
        assertThat(errorElements.get(0).getCssValue("color")).isEqualTo("rgb(255, 0, 0)");
    }

    @ParameterizedTest
    @Order(2)
    @ValueSource(strings = {"password1234", "somanypickles27", "spartans1"})
    public void REGISTER_3_4_PasswordShouldNotBeCommon(String pass) {

        webDriver.get("https://bank-online.studware.ru/");

        WebElement loginButton = webDriver.findElement(By.cssSelector(".button"));
        loginButton.click();

        wait.until(pageLoadCondition);
        assertThat(webDriver.getCurrentUrl()).contains("https://bank-online.studware.ru/login/");
        assertThat(webDriver.getTitle()).isEqualTo("Вход");

        WebElement registerAnchor = webDriver.findElement(By.linkText("Создать учетную запись"));
        registerAnchor.click();

        wait.until(pageLoadCondition);
        assertThat(webDriver.getCurrentUrl()).isEqualTo("https://bank-online.studware.ru/register/");
        assertThat(webDriver.getTitle()).isEqualTo("Регистрация");

        WebElement usernameInput = webDriver.findElement(By.name("username"));
        usernameInput.sendKeys("bvghf_Nikita");
        WebElement passwordInput = webDriver.findElement(By.name("password"));
        passwordInput.sendKeys(pass);

        WebElement button = webDriver.findElement(By.cssSelector("form button"));
        button.click();

        wait.until(pageLoadCondition);
        assertThat(webDriver.getCurrentUrl()).isEqualTo("https://bank-online.studware.ru/register/");

        List<WebElement> errorElements = webDriver.findElements(By.className("error"));
        assertThat(errorElements.size()).isEqualTo(1);
        assertThat(errorElements.get(0).getText()).isEqualTo("Пароль не соответствует требованиям безопасности");
        assertThat(errorElements.get(0).getCssValue("color")).isEqualTo("rgb(255, 0, 0)");
    }


    @Test
    public void LOGIN_3_SuccessLogin() {
        registerTestUser("zxcvb_nikita", "Qwerty1998");
        loginTestUser("zxcvb_nikita", "Qwerty1998");

        assertThat(webDriver.getCurrentUrl()).isEqualTo("https://bank-online.studware.ru/");
        assertThat(webDriver.getTitle()).isEqualTo("Главная страница");

        WebElement userName = webDriver.findElement(By.cssSelector("header > div nav:nth-child(2) a:first-child span"));
        assertThat(userName.getText()).isEqualTo("zxcvb_nikita");

        deleteTestUser();
    }

    @Test
    public void ACCOUNT_1_AccessFailedToUnregisteredUser () {
        webDriver.get("https://bank-online.studware.ru/accounts/");
        wait.until(pageLoadCondition);

        assertThat(webDriver.getCurrentUrl()).contains("https://bank-online.studware.ru/login/");
        assertThat(webDriver.getTitle()).isEqualTo("Вход");
    }

    @Test
    public void ACCOUNT_9_SuccessAccountCreation() {
        registerTestUser("zxcvb_nikita", "Qwerty1998");
        loginTestUser("zxcvb_nikita", "Qwerty1998");

        webDriver.get("https://bank-online.studware.ru/accounts/");
        wait.until(pageLoadCondition);

        WebElement accName = webDriver.findElement(By.name("name"));
        accName.sendKeys("test");
        WebElement balance = webDriver.findElement(By.name("balance"));
        balance.sendKeys("50");
        WebElement createBtn = webDriver.findElement(By.cssSelector("button.create"));
        createBtn.click();

        wait.until(pageLoadCondition);

        WebElement form = webDriver.findElement(By.cssSelector("main div form:nth-last-child(2)"));
        accName = form.findElement(By.cssSelector("input:nth-child(3)"));
        assertThat(accName.getAttribute("value")).isEqualTo("test");
        balance = form.findElement(By.cssSelector("input:nth-child(5)"));
        assertThat(balance.getAttribute("value")).isEqualTo("50");

        WebElement deleteBtn = form.findElement(By.cssSelector("button.delete"));
        deleteBtn.click();

        deleteTestUser();
    }

    @Test
    public void TRANSACTION_2_CorrectHeaderFormat() {
        registerTestUser("zxcvb_nikita", "Qwerty1998");
        loginTestUser("zxcvb_nikita", "Qwerty1998");

        webDriver.get("https://bank-online.studware.ru/transactions/");
        wait.until(pageLoadCondition);

        WebElement transactionHeader = webDriver.findElement(By.linkText("Переводы"));
        assertThat(transactionHeader.getCssValue("color")).isEqualTo("rgb(0, 0, 0)");
        assertThat(transactionHeader.getCssValue("font-weight")).isEqualTo("700");

        deleteTestUser();
    }


    @Test
    public void TRANSACTION_14_3_SuccessMoneyTransferFromSender() {
        registerTestUser("zxcvb_nikita", "Qwerty1998");
        loginTestUser("zxcvb_nikita", "Qwerty1998");

        webDriver.get("https://bank-online.studware.ru/accounts/");
        wait.until(pageLoadCondition);

        WebElement accName = webDriver.findElement(By.name("name"));
        accName.sendKeys("test");
        WebElement balance = webDriver.findElement(By.name("balance"));
        balance.sendKeys("50");
        WebElement createBtn = webDriver.findElement(By.cssSelector("button.create"));
        createBtn.click();

        wait.until(pageLoadCondition);

        WebElement logoutBtn = webDriver.findElement(By.cssSelector("[href=\"/logout/\"]"));
        logoutBtn.click();
        wait.until(pageLoadCondition);

        registerTestUser("asdfg_nikita", "Qwerty1998");
        loginTestUser("asdfg_nikita", "Qwerty1998");

        webDriver.get("https://bank-online.studware.ru/accounts/");
        wait.until(pageLoadCondition);

        accName = webDriver.findElement(By.name("name"));
        accName.sendKeys("test");
        balance = webDriver.findElement(By.name("balance"));
        balance.sendKeys("50");
        createBtn = webDriver.findElement(By.cssSelector("button.create"));
        createBtn.click();
        wait.until(pageLoadCondition);

        webDriver.get("https://bank-online.studware.ru/transactions/");
        wait.until(pageLoadCondition);

        WebElement recipient = webDriver.findElement(By.name("recipient"));
        recipient.sendKeys("zxcvb_nikita");
        WebElement recipientAccName = webDriver.findElement(By.name("recipient_account"));
        recipientAccName.sendKeys("test");
        WebElement sender = webDriver.findElement(By.name("sender"));
        sender.sendKeys("asdfg_nikita");
        WebElement senderAccName = webDriver.findElement(By.name("sender_account"));
        senderAccName.sendKeys("test");
        WebElement description = webDriver.findElement(By.name("description"));
        description.sendKeys("test transaction");
        WebElement amount = webDriver.findElement(By.name("amount"));
        amount.sendKeys("10");

        WebElement confirmBtn = webDriver.findElement(By.cssSelector("form button"));
        confirmBtn.click();
        wait.until(pageLoadCondition);

        webDriver.get("https://bank-online.studware.ru/accounts/");
        wait.until(pageLoadCondition);

        WebElement form = webDriver.findElement(By.cssSelector("main div form:nth-last-child(2)"));
        accName = form.findElement(By.cssSelector("input:nth-child(3)"));
        assertThat(accName.getAttribute("value")).isEqualTo("test");
        balance = form.findElement(By.cssSelector("input:nth-child(5)"));
        assertThat(balance.getAttribute("value")).isEqualTo("40");

        deleteTestUser();
        loginTestUser("zxcvb_nikita", "Qwerty1998");
        deleteTestUser();
    }
}