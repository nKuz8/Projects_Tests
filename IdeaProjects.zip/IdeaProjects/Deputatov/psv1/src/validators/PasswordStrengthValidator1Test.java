package validators;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;

class PasswordStrengthValidator1Test {
    @Test
    void ifLengthLess8ThenStrengthIsTooShort() {
        String actualStrength = PasswordStrengthValidator1.checkPassword("Pswd");
        String expectedStrength = "Too Short";
        assertEquals(expectedStrength, actualStrength);
    }

    @Test
    void ifLengthGreaterThan8ContainsUpperLowerIsWeak() {
        String actualStrength = PasswordStrengthValidator1.checkPassword("Qwertyui");
        String expectedStrength = "Weak";
        assertEquals(expectedStrength, actualStrength);
    }

    @Test
    void ifLengthGreaterThan8ContainsDigitIsWeak() {
        String actualStrength = PasswordStrengthValidator1.checkPassword("12345678");
        String expectedStrength = "Weak";
        assertEquals(expectedStrength, actualStrength);
    }

    @Test
    void ifLengthGreaterThan8ContainsUpperLowerSpecialIsMedium() {
        String actualStrength = PasswordStrengthValidator1.checkPassword("Qwertyui#");
        String expectedStrength = "Medium";
        assertEquals(expectedStrength, actualStrength);
    }

    @Test
    void ifLengthGreaterThan8ContainsUpperLowerDigitIsMedium() {
        String actualStrength = PasswordStrengthValidator1.checkPassword("Qwertyui1");
        String expectedStrength = "Medium";
        assertEquals(expectedStrength, actualStrength);
    }

    @Test
    void ifLengthGreaterThan8ContainsSpecialDigitIsMedium() {
        String actualStrength = PasswordStrengthValidator1.checkPassword("0*2#385~~");
        String expectedStrength = "Medium";
        assertEquals(expectedStrength, actualStrength);
    }

    @Test
    void ifLengthGreaterThan8ContainsUpperLowerSpecialDigitIsStrong() {
        String actualStrength = PasswordStrengthValidator1.checkPassword("Qwertyui1#");
        String expectedStrength = "Strong";
        assertEquals(expectedStrength, actualStrength);
    }
}
