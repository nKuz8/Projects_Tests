package ru.bk252.kkso16;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

class PasswordStrengthValidator1Test {
    @ParameterizedTest
    @CsvSource({"Pswd, Too Short", "Qwertyui, Weak", "12345678, Weak", "Qwertyui#, Medium", "0*2#385~~, Medium", "Qwertyui1#, Strong"})
    void testStrengthValidator1(String pass, String str) {
        assertEquals(PasswordStrengthValidator1.checkPassword(pass), str);
    }
}