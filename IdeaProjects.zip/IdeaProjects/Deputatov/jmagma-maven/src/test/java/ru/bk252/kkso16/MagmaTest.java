package ru.bk252.kkso16;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;

public class MagmaTest
{
    @Test
    public void testEncryption()
    {
        long openBl = 0xfedcba9876543210L;
        int[] key = new int[] {0xffeeddcc, 0xbbaa9988, 0x77665544, 0x33221100, 0xf0f1f2f3, 0xf4f5f6f7, 0xf8f9fafb, 0xfcfdfeff};

        Magma EncryptCheck = new Magma(key);

        assertEquals(EncryptCheck.encryptBlock(openBl), 0x4ee901e5c2d8ca3dL);
    }

    @Test
    public void testDecryption() {
        long cipherBl = 0x4ee901e5c2d8ca3dL;
        int[] key = new int[] {0xffeeddcc, 0xbbaa9988, 0x77665544, 0x33221100, 0xf0f1f2f3, 0xf4f5f6f7, 0xf8f9fafb, 0xfcfdfeff};

        Magma DecryptCheck = new Magma(key);

        assertEquals(DecryptCheck.decryptBlock(cipherBl), 0xfedcba9876543210L);
    }


}
