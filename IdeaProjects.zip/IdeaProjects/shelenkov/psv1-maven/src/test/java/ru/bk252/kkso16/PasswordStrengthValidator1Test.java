package ru.bk252.kkso16;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

class PasswordStrengthValidator1Test {
    @ParameterizedTest
    @CsvSource({"Pswd, Too Short", "zsPSSBzO, Weak", "12345678, Weak", "ElJ46F5X, Medium", "$6@09@2*, Medium", "Zh%3Lw#5, Strong"})
    void testStrengthValidator1(String pass, String str) {
        assertEquals(PasswordStrengthValidator1.checkPassword(pass), str);
    }
}

