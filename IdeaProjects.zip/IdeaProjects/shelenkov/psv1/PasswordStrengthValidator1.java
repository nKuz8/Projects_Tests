public class PasswordStrengthValidator1 {

    public static String checkPassword(String inputPassword) {
        int uppercase = 0;
        int lowercase = 0;
        int specialcharacters = 0;
        int digits = 0;
        char[] Password = inputPassword.toCharArray();
        String result = "";
        for (int index = 0; index < inputPassword.length(); index++) {
            if (Character.isUpperCase(Password[index])) {
                uppercase = 1;
            }
            if (Character.isLowerCase(Password[index])) {
                lowercase = 1;
            }
            if (Character.isDigit(Password[index])) {
                digits = 1;
            }
        }
        if (inputPassword.contains("~") || inputPassword.contains("!") || inputPassword.contains("@")
                || inputPassword.contains("#") || inputPassword.contains("$") || inputPassword.contains("%")
                || inputPassword.contains("^") || inputPassword.contains("&") || inputPassword.contains("*")) {
            specialcharacters = 1;
        }
        if (inputPassword.length() < 8)

            result = "Too Short";

        if (inputPassword.length() >= 8 && (((uppercase == 1) && (lowercase == 1)) || (digits == 1) || (specialcharacters == 1)))

            result = "Weak";

        if ((inputPassword.length() >= 8 && (((uppercase == 1) && (lowercase == 1)) || (digits == 1) && (specialcharacters == 1)))
                &&
                (inputPassword.length() >= 8 && (((uppercase == 1) && (lowercase == 1)) && (digits == 1) || (specialcharacters == 1))))

            result = "Medium";

        if (inputPassword.length() >= 8 && (uppercase == 1) && (lowercase == 1) && (digits == 1) && (specialcharacters == 1))

            result = "Strong";

        return result;
    }

    private static boolean testLengthLessThan8IsTooShort() {
        String category = checkPassword("Pswd");
        if (category == "Too Short") {
            return true;
        } else {
            return false;
        }
    }

    private static boolean testLengthGreaterThan8ContainsUpperLowerIsWeak() {
        String category = checkPassword("zsPSSBzO");
        if (category == "Weak") {
            return true;
        } else {
            return false;
        }
    }

    private static boolean testLengthGreaterThan8ContainsDigitIsWeak() {
        String category = checkPassword("12345678");
        if (category == "Weak") {
            return true;
        } else {
            return false;
        }
    }

    private static boolean testLengthGreaterThan8ContainsUpperLowerSpecialIsMedium() {
        String category = checkPassword("tKI*bG*E");
        if (category == "Medium") {
            return true;
        } else {
            return false;
        }
    }

    private static boolean testLengthGreaterThan8ContainsUpperLowerDigitIsMedium() {
        String category = checkPassword("ElJ46F5X");
        if (category == "Medium") {
            return true;
        } else {
            return false;
        }
    }

    private static boolean testLengthGreaterThan8ContainsSpecialDigitIsMedium() {
        String category = checkPassword("$6@09@2*");
        if (category == "Medium") {
            return true;
        } else {
            return false;
        }
    }

    private static boolean testLengthGreaterThan8ContainsUpperLowerSpecialDigitIsStrong() {
        String category = checkPassword("Zh%3Lw#5");
        if (category == "Strong") {
            return true;
        } else {
            return false;
        }
    }

    public static void main(String[] args) {
        if (testLengthLessThan8IsTooShort()) {
            System.out.println("test LengthLessThan8 Is TooShort: OK");
        } else {
            System.out.println("test LengthLessThan8 Is TooShort: FAIL");
        }

        if (testLengthGreaterThan8ContainsUpperLowerIsWeak()) {
            System.out.println("test LengthGreaterThan8ContainsUpperLower Is Weak : OK");
        } else {
            System.out.println("test LengthGreaterThan8ContainsUpperLower Is Weak : FAIL");
        }

        if (testLengthGreaterThan8ContainsDigitIsWeak()) {
            System.out.println("test LengthGreaterThan8ContainsDigit Is Weak : OK");
        } else {
            System.out.println("test LengthGreaterThan8ContainsDigit Is Weak : FAIL");
        }

        if (testLengthGreaterThan8ContainsUpperLowerSpecialIsMedium()) {
            System.out.println("test LengthGreaterThan8ContainsUpperLowerSpecial Is Medium : OK");
        } else {
            System.out.println("test LengthGreaterThan8ContainsUpperLowerSpecial Is Medium : FAIL");
        }

        if (testLengthGreaterThan8ContainsUpperLowerDigitIsMedium()) {
            System.out.println("test LengthGreaterThan8ContainsUpperLowerDigit Is Medium : OK");
        } else {
            System.out.println("test LengthGreaterThan8ContainsUpperLowerDigit Is Medium : FAIL");
        }

        if (testLengthGreaterThan8ContainsSpecialDigitIsMedium()) {
            System.out.println("test LengthGreaterThan8ContainsSpecialDigit Is Medium : OK");
        } else {
            System.out.println("test LengthGreaterThan8ContainsSpecialDigit Is Medium : FAIL");
        }

        if (testLengthGreaterThan8ContainsUpperLowerSpecialDigitIsStrong()) {
            System.out.println("test LengthGreaterThan8ContainsUpperLowerSpecialDigit Is Strong : OK");
        } else {
            System.out.println("test LengthGreaterThan8ContainsUpperLowerSpecialDigit Is Strong : FAIL");
        }

    }
}
